include('shared.lua')

function ENT:Initialize()

end

function ENT:CreateBoom()

end

function ENT:OnRemove()


end

function ENT:Think()

end

function ENT:Draw()
	
end

