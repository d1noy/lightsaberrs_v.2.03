
--[[-------------------------------------------------------------------
	Lightsaber Force Powers:
		The available powers that the new saber base uses.
			Powered by
						  _ _ _    ___  ____  
				__      _(_) | |_ / _ \/ ___| 
				\ \ /\ / / | | __| | | \___ \ 
				 \ V  V /| | | |_| |_| |___) |
				  \_/\_/ |_|_|\__|\___/|____/ 
											  
 _____         _                 _             _           
|_   _|__  ___| |__  _ __   ___ | | ___   __ _(_) ___  ___ 
  | |/ _ \/ __| '_ \| '_ \ / _ \| |/ _ \ / _` | |/ _ \/ __|
  | |  __/ (__| | | | | | | (_) | | (_) | (_| | |  __/\__ \
  |_|\___|\___|_| |_|_| |_|\___/|_|\___/ \__, |_|\___||___/
                                         |___/             
----------------------------- Copyright 2017, David "King David" Wiltos ]]--[[
							  
	Lua Developer: King David
	Contact: http://steamcommunity.com/groups/wiltostech
		
-- Copyright 2017, David "King David" Wiltos ]]--

local TREE = {}

--Name of the skill tree
TREE.Name = "Jedi Consular"

--Description of the skill tree
TREE.Description = "One with the Force"

--Icon for the skill tree ( Appears in category menu and above the skills )
TREE.TreeIcon = "wos/skilltrees/ravager/emergent.png"

--What is the background color in the menu for this 
TREE.BackgroundColor = Color( 255, 0, 0, 25 )

--How many tiers of skills are there?
TREE.MaxTiers = 5

--Add user groups that are allowed to use this tree. If anyone is allowed, set this to FALSE ( TREE.UserGroups = false )
TREE.UserGroups = false
TREE.Tier = {}

TREE.Tier[1] = {}
TREE.Tier[1][1] = {
	Name = "Consular",
	Description = "Be one with the force, +100 saber damage",
	Icon = "wos/skilltrees/ravager/emergent.png",
	PointsRequired = 25,
	Requirements = {},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) wep.SaberDamage = wep.SaberDamage + 100 end,
}

TREE.Tier[2] = {}
TREE.Tier[2][2] = {
	Name = "Lapis Mirror",
	Description = "Finally you are free",
	Icon = "wos/skilltrees/ravager/emergent.png",
	PointsRequired = 40,
	Requirements = {
	[1] = { 1 },
	},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) wep:AddForcePower( "Lapis Mirror" ) end,
}

TREE.Tier[2][1] = {
	Name = "Armor of the Force",
	Description = "Adds 50 Armor to your current Armor",
	Icon = "wos/skilltrees/ravager/emergent.png",
	PointsRequired = 50,
	Requirements = {
	[2] = { 2 },
	},
	OnPlayerSpawn = function( ply ) ply:SetArmor( ply:Armor() + 50 ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) end,
}

TREE.Tier[2][3] = {
	Name = "Armor of the Force",
	Description = "Adds 50 Armor to your current Armor",
	Icon = "wos/skilltrees/ravager/emergent.png",
	PointsRequired = 60,
	Requirements = {
	[2] = { 2 },
	},
	OnPlayerSpawn = function( ply ) ply:SetArmor( ply:Armor() + 50 ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) end,
}

TREE.Tier[3] = {}
TREE.Tier[3][1] = {
	Name = "Not a step back 1",
	Description = "Adds 100 Health to your current Health",
	Icon = "wos/skilltrees/ravager/emergent.png",
	PointsRequired = 70,
	Requirements = {
	[2] = { 1 },
	},
	OnPlayerSpawn = function( ply ) ply:SetHealth( ply:Health() + 100 ) ply:SetMaxHealth( ply:GetMaxHealth() + 100 ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) end,
}

TREE.Tier[3][2] = {
	Name = "Not a step back 2",
	Description = "Adds 100 Health to your current Health",
	Icon = "wos/skilltrees/ravager/emergent.png",
	PointsRequired = 80,
	Requirements = {
	[2] = { 3 },
	},
	OnPlayerSpawn = function( ply ) ply:SetHealth( ply:Health() + 100 ) ply:SetMaxHealth( ply:GetMaxHealth() + 100 ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) end,
}

TREE.Tier[4] = {}
TREE.Tier[4][1] = {
	Name = "Force Whirlwind",
	Description = "That which you harness is all around you",
	Icon = "wos/skilltrees/ravager/emergent.png",
	PointsRequired = 90,
	Requirements = {
	[3] = { 1, 2 },
	[2] = { 2 },
	},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) wep:AddForcePower( "Force Whirlwind" ) end,
}

TREE.Tier[5] = {}
TREE.Tier[5][1] = {
	Name = "Balance of the Force",
	Description = "I'm one with power and power is one with me",
	Icon = "wos/skilltrees/ravager/emergent.png",
	PointsRequired = 100,
	Requirements = {
	[4] = { 1 },
	},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) wep:AddForcePower( "Balance of the Force" ) end,
}

wOS:RegisterSkillTree( TREE )