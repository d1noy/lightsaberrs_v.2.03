﻿
--[[-------------------------------------------------------------------
	Lightsaber Force Powers:
		The available powers that the new saber base uses.
			Powered by
						  _ _ _    ___  ____  
				__      _(_) | |_ / _ \/ ___| 
				\ \ /\ / / | | __| | | \___ \ 
				 \ V  V /| | | |_| |_| |___) |
				  \_/\_/ |_|_|\__|\___/|____/ 
											  
 _____         _                 _             _           
|_   _|__  ___| |__  _ __   ___ | | ___   __ _(_) ___  ___ 
  | |/ _ \/ __| '_ \| '_ \ / _ \| |/ _ \ / _` | |/ _ \/ __|
  | |  __/ (__| | | | | | | (_) | | (_) | (_| | |  __/\__ \
  |_|\___|\___|_| |_|_| |_|\___/|_|\___/ \__, |_|\___||___/
                                         |___/             
----------------------------- Copyright 2017, David "King David" Wiltos ]]--[[
							  
	Lua Developer: King David
	Contact: http://steamcommunity.com/groups/wiltostech
		
-- Copyright 2017, David "King David" Wiltos ]]--

local TREE = {}

--Name of the skill tree
TREE.Name = "Jedi guardian"
TREE.JobRestricted = { "TEAM_JD10", "TEAM_JD4", "TEAM_JD6", "TEAM_JD9", "TEAM_JD10", "TEAM_JD15", "TEAM_JD20", "TEAM_JD19", "TEAM_JD21", "TEAM_JD14", "TEAM_JD13", "TEAM_GRAY2", "TEAM_GRAY3", "TEAM_GRAY4", "TEAM_GRAY1233"}
--Description of the skill tree
TREE.Description = "Защитите себя, защитите своих друзей"

--Icon for the skill tree ( Appears in category menu and above the skills )
TREE.TreeIcon = "materials/mar8studios/jedicons/3284130438_310884619.png"

--What is the background color in the menu for this 
TREE.BackgroundColor = Color( 255, 0, 0, 25 )

--How many tiers of skills are there?
TREE.MaxTiers = 6

--Add user groups that are allowed to use this tree. If anyone is allowed, set this to FALSE ( TREE.UserGroups = false )
--TREE.UserGroups = { 'jedi', 'admin', 'superadmin', 'founder', 'cmd', 'eventmaster', 'adminpay', 'cmd_eventmaster', 'curator', 'admin_spec', 'zam_cmd', 'gladmin', 'watching rp'}
TREE.UserGroups = false

TREE.Tier = {}

--Tier format is as follows:
--To create the TIER Table, do the following
--TREE.Tier[ TIER NUMBER ] = {} 
--To populate it with data, the format follows this
--TREE.Tier[ TIER NUMBER ][ SKILL NUMBER ] = DATA
--Name, description, and icon are exactly the same as before
--PointsRequired is for how many skill points are needed to unlock this particular skill
--Requirements prevent you from unlocking this skill unless you have the pre-requisite skills from the last tiers. If you are on tier 1, this should be {}
--OnPlayerSpawn is a function called when the player just spawns
--OnPlayerDeath is a function called when the player has just died
--OnSaberDeploy is a function called when the player has just pulled out their lightsaber ( assuming you have SWEP.UsePlayerSkills = true )

TREE.Tier[1] = {}
TREE.Tier[1][1] = {
	Name = "Страж",
	Description = "Когда вы блокируете удары, вы лечите себя",
	Icon = "materials/mar8studios/jedicons/3146548022_1837128637.png",
	PointsRequired = 5,
	Requirements = {},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberBlocked = function( ply ) ply:SetHealth( math.Clamp( ply:Health() + 50, 0, ply:GetMaxHealth() ) ) end,
}

TREE.Tier[2] = {}
TREE.Tier[2][2] = {
	Name = "Electric Judgement",
	Description = "Заставляет пасть на колени вашу цель",
	Icon = "materials/mar8studios/jedicons/137576510_345989627.png",
	PointsRequired = 10,
	Requirements = {
	[1] = { 1 },
	},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) wep:AddForcePower( "Electric Judgement" ) end,
}

TREE.Tier[2][1] = {
	Name = "Броня",
	Description = "Прибавляет +150 брони",
	Icon = "materials/mar8studios/jedicons/3687018237_3445187610.png",
	PointsRequired = 4,
	Requirements = {
	[2] = { 2 },
	},
	OnPlayerSpawn = function( ply ) ply:SetArmor( ply:Armor() + 150 ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) end,
}

TREE.Tier[2][3] = {
	Name = "Броня",
	Description = "Прибавляет +150 брони",
	Icon = "materials/mar8studios/jedicons/3687018237_3445187610.png",
	PointsRequired = 4,
	Requirements = {
	[2] = { 2 },
	},
	OnPlayerSpawn = function( ply ) ply:SetArmor( ply:Armor() + 150 ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) end,
}

TREE.Tier[3] = {}
TREE.Tier[3][1] = {
	Name = "Здоровье",
	Description = "Прибавляет +250 здоровья",
	Icon = "materials/mar8studios/jedicons/2120838239_1498357567.png",
	PointsRequired = 4,
	Requirements = {
	[2] = { 1 },
	},
	OnPlayerSpawn = function( ply ) ply:SetHealth( ply:Health() + 250 ) ply:SetMaxHealth( ply:GetMaxHealth() + 250 ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) end,
}

TREE.Tier[3][2] = {
	Name = "Здоровье",
	Description = "Прибавляет +250 здоровья",
	Icon = "materials/mar8studios/jedicons/2120838239_1498357567.png",
	PointsRequired = 4,
	Requirements = {
	[2] = { 3 },
	},
	OnPlayerSpawn = function( ply ) ply:SetHealth( ply:Health() + 250 ) ply:SetMaxHealth( ply:GetMaxHealth() + 250 ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) end,
}

TREE.Tier[4] = {}
TREE.Tier[4][1] = {
	Name = "Saber Barrier",
	Description = "Создает Saber Barrier с помощью вашего меча",
	Icon = "materials/mar8studios/jedicons/939748054_4195477517.png",
	PointsRequired = 15,
	Requirements = {
	[3] = { 1, 2 },
	[2] = { 2 },
	},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) wep:AddForcePower( "Saber Barrier" ) end,
}

TREE.Tier[5] = {}
TREE.Tier[5][1] = {
	Name = "Force Absorb",
	Description = "Поглощает входящий урон",
	Icon = "materials/mar8studios/jedicons/2163992666_3072989036.png",
	PointsRequired = 25,
	Requirements = {
	[4] = { 1 },
	},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) wep:AddForcePower( "Force Absorb" ) end,
}

TREE.Tier[6] = {}
TREE.Tier[6][1] = {
	Name = "Хорошая защита - это нападение",
	Description = "Прибавляет +100 урона меча",
	Icon = "materials/mar8studios/jedicons/1008605386_1452798731.png",
	PointsRequired = 5,
	Requirements = {},
	OnPlayerSpawn = function( ply ) end,
	OnPlayerDeath = function( ply ) end,
	OnSaberDeploy = function( wep ) wep.SaberDamage = wep.SaberDamage + 75 end,
}






wOS:RegisterSkillTree( TREE )