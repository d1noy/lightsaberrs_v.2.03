local FORM = {}

--The name of this form. Do not repeat names of forms!
FORM.Name = "Training"

--Who does this form belong to? Options: FORM_SINGLE, FORM_DUAL, FORM_BOTH
FORM.Type = FORM_SINGLE

--What user groups are able to use this form? And which stances?
FORM.UserGroups = { 
	["user"] = { 1 }, 
	["jedi"] = { 1, 2, 3 },
}

FORM.Stances = {}

FORM.Stances[1] = {
	[ "run" ] = "phalanx_h_run",
	[ "idle" ] = "idle_all_scared",
	[ "light_left" ] = {
		Sequence = "judge_h_s1_t3",
		Time = 1,
		Rate = nil,
	},
	[ "light_right" ] = {
		Sequence = "pure_h_right_t1",
		Time = 1,
		Rate = nil,
	},
	[ "light_forward" ] = {
		Sequence = "judge_h_s3_t3",
		Time = nil,
		Rate = nil,
	},
	[ "air_left" ] = {
		Sequence =  "phalanx_a_left_t1",
		Time = nil,
		Rate = 2,
	},
	[ "air_right" ] = {
		Sequence = "phalanx_a_right_t1",
		Time = 0.3,
		Rate = 1.7,
	},
	[ "air_forward" ] = {
		Sequence = "phalanx_a_s1_t1",
		Time = 0.3,
		Rate = 1.2,
	},
	[ "heavy" ] = {
		Sequence = "flourish_bow_basic",
		Time = 0.4,
		Rate = 3,
	},
	[ "heavy_charge" ] = "h_c1_charge",
}		
		
wOS:RegisterNewForm( FORM )