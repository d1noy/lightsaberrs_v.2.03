wOS = wOS or {}
wOS.ALCS = wOS.ALCS or {}

hook.Add( "InitPostEntity", "wOS.ALCS.Webacktodoingthisshitagainuntilthenextupdate", function()

	local _CALC = GAMEMODE.CalcMainActivity
	function GAMEMODE:CalcMainActivity( ply, velocity )
		local seq
		if !ply:InVehicle() then

			if ply:GetNW2Float( "wOS.ChokeTime", 0 ) >= CurTime() then
				seq = ply:LookupSequence( "wos_force_choke" )
			end

			if seq and seq > 0 then
				return -1, seq	
			end
		end
		return _CALC( self, ply, velocity )
	end

end )